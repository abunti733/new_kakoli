
<h1 style="color:#65BDB6;"><i class="fa-solid fa-user-tie px-2" style="font-size:35px"></i>Add User<small> Statistics Overview</small></h1>
<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
  <ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
    <li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-user-tie px-2" style="font-size:18px;color:#65BDB6;"></i>Add User</a></li>
  </ol>
</nav>



<?php 
require("db_con.php");
if(isset($_POST['submit'])){
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];
    date_default_timezone_set("Asia/Dhaka");
    $registe_date = date("Y-m-d h:i:sa");
    $input_error = array();
    if(empty($full_name)){
        $input_error['full_name'] = "* Name is required";
    }
    if(empty($username)){
        $input_error['username'] = "* Username is required";
    }
    if(empty($fname)){
        $input_error['fname'] = "* Father Name is required";
    }
    if(empty($mname)){
        $input_error['mname'] = "* Mother Name is required";
    }
    if(empty($phone)){
        $input_error['phone'] = "* Phone Number is required";
    }
    if(empty($email)){
        $input_error['email'] = "* email Address is required";
    }
    if(empty($address)){
        $input_error['address'] = "* Name is required";
    }
    if(empty($password)){
        $input_error['password'] = " *Password is required";
    }
    if(empty($c_password)){
        $input_error['c_password'] = "* Confirm Password is required";
    }

    if(count($input_error) == 0){
      if(strlen($username) > 5){
        if(strlen($password) > 8 ){
          if($password == $c_password){
            $username_unique = mysqli_query($db_con , "SELECT * FROM `user_register_data` WHERE `username` = '$username'");
            if(mysqli_num_rows($username_unique) == 0){
              $email_unique = mysqli_query($db_con , "SELECT * FROM `user_register_data` WHERE `email` = '$email'");
              if(mysqli_num_rows($email_unique) == 0){
                  $password = md5($password);
                  $insert = mysqli_query($db_con , "INSERT INTO `user_register_data`(`name`, `username`, `father name`, `mother name`, `phone`, `email`, `address`, `password`, `register time`, `status`) VALUES ('$full_name','$username','$fname','$mname','$phone','$email','$address','$password','$registe_date','Inactive')");
                  if($insert){
                    echo "<script>
                    alert('Successfully Register You Account');
                    </script>";
                    $full_name = false ;
                    $username = false ;
                    $fname = false ;
                    $mname = false ;
                    $phone = false ;
                    $email = false ;
                    $address = false ;
                    $password = false ;
                    $c_password = false ; 
                  }
              }else{
                $input_error['email'] = "* email is already exist";
              }
            }else{
              $input_error['username'] = "* Username is already exist";
            }
          }else{
            $input_error['c_password'] = "* Password cannot match";
          }
        }else{
          $input_error['password'] = " * Password must be above 8 character";
        }
      }else{
        $input_error['username'] = "* Username must be above 5 character";
      }
    }
}
?>

    <form action="" method="post" style="padding-bottom: 50px;">
    <div class="con-12">
    <div class="row"> 
                    <!-- column start -->
					<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label"> Name<small style="color:#65BDB6">*</small></label>
							<input  class="form-control" type="text" name="full_name" value="<?php if(isset($full_name)){echo $full_name;}?>">
							<label class="text-danger"><?php if(isset($input_error['full_name'])){echo $input_error['full_name'];}?></label>				
						</div>
						<!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label"> Username<small style="color:#65BDB6">*</small></label>
							<input  class="form-control" type="text" name="username" value="<?php if(isset($username)){echo $username;}?>">
							<label class="text-danger"><?php if(isset($input_error['username'])){echo $input_error['username'];}?></label>				
						</div>
						<!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label">Father's Name<small style="color:#65BDB6">*</small></label>
							<input type="text" class="form-control" type="text" name="fname" value="<?php if(isset($fname)){echo $fname;}?>">
							<label class="text-danger"><?php if(isset($input_error['fname'])){
							 echo $input_error['fname'];}?></label>					
						</div>
                        <!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label">Mother's Name<small style="color:#65BDB6">*</small></label>
							<input type="text" class="form-control" type="text" name="mname" value="<?php if(isset($mname)){echo $mname;}?>">
							<label class="text-danger"><?php if(isset($input_error['mname'])){
							 echo $input_error['mname'];}?></label>					
						</div>
                        <!-- end -->
						<!-- start -->
						<div class="mb-1">
							<label class="form-label">Phone<small style="color:#65BDB6">*</small></label>
							<input type="text" class="form-control" name="phone" value="<?php if(isset($phone)){echo $phone;}?>">
							<label class="text-danger"><?php if(isset($input_error['phone'])){
							 echo $input_error['phone'];}?></label>		
						</div>
                        <!-- end -->
					</div>
                    <!-- column end -->
                    <!-- column start -->
					<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label"> Email<small style="color:#65BDB6">*</small></label>
							<input  class="form-control" type="email" name="email" value="<?php if(isset($email)){echo $email;}?>">
							<label class="text-danger"><?php if(isset($input_error['email'])){echo $input_error['email'];}?></label>				
						</div>
						<!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label"> address<small style="color:#65BDB6">*</small></label>
							<input  class="form-control" type="text" name="address" value="<?php if(isset($address)){echo $address;}?>">
							<label class="text-danger"><?php if(isset($input_error['address'])){echo $input_error['address'];}?></label>				
						</div>
						<!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label">Password<small style="color:#65BDB6">*</small></label>
							<input type="password" class="form-control" type="password" name="password" value="<?php if(isset($password)){echo $password;}?>">
							<label class="text-danger"><?php if(isset($input_error['password'])){
							 echo $input_error['password'];}?></label>					
						</div>
                        <!-- end -->
                        <!-- start -->
						<div class="mb-1">
							<label class="form-label">Confirm Password<small style="color:#65BDB6">*</small></label>
							<input type="password" class="form-control" type="password" name="c_password" value="<?php if(isset($c_password)){echo $c_password;}?>">
							<label class="text-danger"><?php if(isset($input_error['c_password'])){
							 echo $input_error['c_password'];}?></label>					
						</div>
                        <!-- end -->
					</div>
                    <!-- column end -->
                             <!-- submit btn start -->
			<div class="ad_btn">
				<input type="submit" value="Registe Now" class="submit_btn" name="submit" style="padding: 8px 20px; background-color: #13A89E; border: none; color: white; border-radius: 10px;">
			</div>
            <!-- submit btn end -->
                </div>
                </div>
      