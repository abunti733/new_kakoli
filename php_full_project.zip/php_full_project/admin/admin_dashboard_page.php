<?php
require_once 'db_con.php';
$total_student_select=mysqli_query($db_con,"SELECT * FROM `admission_form`");
$total_student=mysqli_num_rows($total_student_select);
$total_account_select=mysqli_query($db_con,"SELECT * FROM `admission_form`");
$total_account=mysqli_num_rows($total_account_select);
$total_offline_account_select=mysqli_query($db_con,"SELECT * FROM `admission_form` WHERE `course_type` = 'Offline' ");
$total_offline_account=mysqli_num_rows($total_offline_account_select);
$total_online_account_select=mysqli_query($db_con,"SELECT * FROM `admission_form` WHERE `course_type` = 'Online' ");
$total_online_account=mysqli_num_rows($total_online_account_select);
?>

<div class="dashboard p-3">
<div class="content p-2">
<h1 style="color:#65BDB6;"><i class="fa-solid fa-gauge px-2" style="font-size:35px"></i>Dashboard<small> Statistics Overview</small></h1>
<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
  <ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
    <li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-gauge px-2" style="font-size:18px;color:#65BDB6;"></i>Dashboard</a></li>
    
  </ol>
</nav>
<div class="row">

        <div class="col-sm-3">
            <div class="panel-primary">
                <div class="panel-heading p-2" style="background-color:#65BDB6;">
                    <div class="row">
                        <div class="col-xs-3"><i class="fa fa-users" style="font-size:40px;color:white;"></i></div>
                        <div class="col-xs-9">
                            <div class="float-end" style="font-size:30px;font-weight:bold;color:white;"> <?=$total_student;?></div>
                            <div class="clearfix"></div>
                            <div class="float-end" style="color:white;">All Students</div>
                        </div>
                    </div>
                </div>
                <a href="admin_index.php?page=all_student_list" class="text-decoration-none">
                    <div class="panel-footer p-2" style="background-color:#f5f5f5;">
                        <span class="pull-left" style="color:#65BDB6;">Views All Students</span>
                        <span class="float-end"><i style="color:#65BDB6;" class="fa-solid fa-circle-arrow-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>

        </div>
        
        <div class="col-sm-3">
            <div class="panel-primary">
                <div class="panel-heading p-2" style="background-color:#65BDB6;">
                    <div class="row">
                        <div class="col-xs-3"><i class="fa fa-users" style="font-size:40px;color:white;"></i></div>
                        <div class="col-xs-9">
                            <div class="float-end" style="font-size:30px;font-weight:bold;color:white;"><?=$total_offline_account;?></div>
                            <div class="clearfix"></div>
                            <div class="float-end" style="color:white;">Offline Students</div>
                        </div>
                    </div>
                </div>
                <a href="admin_index.php?page=offline_student_list" class="text-decoration-none">
                    <div class="panel-footer p-2" style="background-color:#f5f5f5;">
                        <span class="pull-left" style="color:#65BDB6;">Views Offline Student</span>
                        <span class="float-end"><i style="color:#65BDB6;" class="fa-solid fa-circle-arrow-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>

        </div>
        
        <div class="col-sm-3">
            <div class="panel-primary">
                <div class="panel-heading p-2" style="background-color:#65BDB6;">
                    <div class="row">
                        <div class="col-xs-3"><i class="fa fa-users" style="font-size:40px;color:white;"></i></div>
                        <div class="col-xs-9">
                            <div class="float-end" style="font-size:30px;font-weight:bold;color:white;"><?=$total_online_account;?></div>
                            <div class="clearfix"></div>
                            <div class="float-end" style="color:white;">Online  Student</div>
                        </div>
                    </div>
                </div>
                <a href="admin_index.php?page=online_student_list" class="text-decoration-none">
                    <div class="panel-footer p-2" style="background-color:#f5f5f5;">
                        <span class="pull-left" style="color:#65BDB6;">Views Online Student</span>
                        <span class="float-end"><i style="color:#65BDB6;" class="fa-solid fa-circle-arrow-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>

        </div>
        
        <div class="col-sm-3">
            <div class="panel-primary">
                <div class="panel-heading p-2" style="background-color:#65BDB6;">
                    <div class="row">
                        <div class="col-xs-3"><i class="fa fa-users" style="font-size:40px;color:white;"></i></div>
                        <div class="col-xs-9">
                            <div class="float-end" style="font-size:30px;font-weight:bold;color:white;"><?=$total_account;?></div>
                            <div class="clearfix"></div>
                            <div class="float-end" style="color:white;">Total Account</div>
                        </div>
                    </div>
                </div>
                <a href="admin_index.php?page=all_account_list" class="text-decoration-none">
                    <div class="panel-footer p-2" style="background-color:#f5f5f5;">
                        <span class="pull-left" style="color:#65BDB6;">Views Account</span>
                        <span class="float-end"><i style="color:#65BDB6;" class="fa-solid fa-circle-arrow-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>

        </div>
        
      
    </div>
    
</div>
<div class="table p-2">
		<table id="data_table" class="table table-striped table-hover">
		<thead>
            <tr>
			
                
                <th>Roll</th>
                <th>Name</th>
                <th>Father's Name</th>
                <th>Course</th>
                <th>Mobile</th>   
                <th>Blood Group</th>          
				<th>Admission Date</th>
                <th>Session</th>
                <th>Photo</th>
                <th>Action</th>
				
               
               
            </tr>
		</thead>
        <tbody>
           <?php
		   
				$admission_data_select_query=mysqli_query($db_con,"SELECT * FROM `admission_form` WHERE `id`");
				while($all_student_data=mysqli_fetch_assoc($admission_data_select_query)){
           
					?>				
						<tr> 												
							
							<td><?=$all_student_data["id"];?></td>
							<td><?=$all_student_data["student_name"];?></td>
							<td><?=$all_student_data["father_name"];?></td>
							<td><?=$all_student_data["course"];?></td>
							<td><?=$all_student_data["phone_number"];?></td>
                            <td><?=$all_student_data['blood_group'];?></td>
							<td><?=$all_student_data["admission_time"];?></td>
                            <td><?=$all_student_data['session'];?></td>
							<td><img src="images/<?=$all_student_data['photo'];?>" class="img-thumbnail s_photo"/></td>
                            <td>
								<div class="btn-group">
										<button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
											Action
										</button>
										<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="student_profile_function.php?student_id=<?php echo base64_encode($all_student_data['id']);?>">View</a></li>
							
															<li><a class="dropdown-item" onclick="return confirm('Are you sure to delete this data?')" href="student_data_delete.php?student_id=<?=base64_encode($all_student_data["id"])?>">Delete</a>
															</li>
									</ul>
									</div>
									</td>


                                   
												
					
				

																			
						</tr>
					
					<?php
				
				}	
		?>
        </tbody>
    </table>
</div>
</div>
