<?php
require('db_con.php');
	session_start();
	if (!isset($_SESSION['User_name'])) {
		header('location:../login form/login_admin_index_form.php');
	}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="shortcut icon" href="../images/site-icon.png" type="image/x-icon">
<title>FCTI SOFTWARE COMPANY LIMITED</title>
       <!-- custome css link -->
	   <link rel="stylesheet" href="./css/style.css" />
	   <link rel="stylesheet" href="./css/form.style.css" />
	   <link rel="stylesheet" href="./css/button.css" />
	   <link rel="stylesheet" href="./css/style.table.css">
	   <link rel="stylesheet" href="./css/bootstrap_modify.css">
	   <link rel="stylesheet" href="./css/admin.style.css" />
	   <link rel="stylesheet" href="./css/dataTables.bootstrap5.min.css" />
	   <link rel="stylesheet" href="./css/bootstrap.min.css">
	   <link rel="stylesheet" href="./css/buttons.dataTables.min.css">
	   <link rel="stylesheet" href="./css/style.reg.css" />

	   
	  
		
		<!-- font-awesome cdn -->
		<link rel="stylesheet" href="./fontawesome/css/all.css">
    	<link rel="stylesheet" href="./fontawesome/css/fontawesome.min.css">
	</head>
<body>
<?php

$logo_data_select = mysqli_query($db_con , "SELECT * FROM `institute_logo` WHERE `id`='1'");
$logo_data_fatch = mysqli_fetch_assoc($logo_data_select);

?>
<div class="main_div">
<div class="navbar">
			<div class="logo"><img width="200px" src="./images/<?=$logo_data_fatch['logo'];?>" alt="" /></div>
			<div class="menu-content">
				<div class="main-content">
				<ul>
					<li class="notification" onclick="dropdown1()"><a href=""><i class="fa-solid fa-bell"></i><span class="badge"></span></a>
						<div class="sub_menu sub_menu_click-1"> 
							<ul>
								<li><a href="admin_index.php?page=student_message">Student Messages</a></li>
								
							</ul>
						</div>
					
					</li>
					<?php  
					$username_main = $_SESSION['User_name'];
					$username_data_select = mysqli_query($db_con , "SELECT * FROM `user_register_data` WHERE `username`='$username_main'");
					$user_data_fatch = mysqli_fetch_assoc($username_data_select);
					?>
					<li class="profile_name" onclick="dropdown2()"  ><img width="50px" style="border-radius: 50%;" src="images/<?=$user_data_fatch['photo']?>" alt="" /> <span>MD ALIF<i style="padding-left: 5px;" class="fa-solid fa-caret-down"></i></span>
						<div class="sub_menu sub_menu_click-2"> 
							<ul>
								<li><a href="admin_index.php?page=edit_user_profile">Edit Profile</a></li>
								<li><a href="admin_index.php?page=change_password">Change Password</a></li>
								<li><a href="../login form/logout.php">Logout</a></li>
							</ul>
						</div>
					
					</li>
				</ul>
				</div>
			</div>

</div>

<div class="container-fluid" style="padding-left:0;position:relative">
	<section class="section-content">
			<div class="row d-flex">
				<div class="col-sm-12 col-md-12 col-lg-3 col-xxl-2" > 
					<nav class="sidebar card">
						<ul class="nav flex-column" id="nav_accordion">
							<li class="nav-item">
								<a class="list-group-item dashboard" href="admin_index.php?page=admin_dashboard_page"><i class="fa-solid fa-dashboard" style="padding-right:7px;"></i>Dashboard</a>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-user-plus nav-icon"></i>Admission <i class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=admission_form">Admission</a></li>
									<li><a class="nav-link" href="admin_index.php?page=admission_report">Admission Report</a></li>
									<li><a class="nav-link" href="admin_index.php?page=user_wise_admission">User Wise Student</a></li>
									
								</ul>
							</li>	
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-user-plus nav-icon"></i>Courses <i class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=add_course">Add Course</a></li>
									<li><a class="nav-link" href="admin_index.php?page=all_course">All Courses</a></li>
									
								</ul>
							</li>	
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-user-tie nav-icon"></i>Student Account<i class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=all_student_account_list">All Student Account List</a></li>
									<li><a class="nav-link" href="admin_index.php?page=student_active_account">Student Active Account</a></li>
									<li><a class="nav-link" href="admin_index.php?page=student_inactive_account">Student Inactive Account</a></li>
								</ul>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-gear nav-icon"></i>Setting<i class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=edit_user_profile">Edit Profile</a></li>
									<li><a class="nav-link" href="admin_index.php?page=change_password">Change Password</a></li>
									<li><a class="nav-link" href="admin_index.php?page=user_list">User List</a></li>
									<li><a class="nav-link" href="admin_index.php?page=add_user">Add User</a></li>
									<li><a class="nav-link" href="admin_index.php?page=main_logo_change">Logo Change</a></li>
								</ul>
							</li>

							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-user-tie nav-icon"></i> Student List<i class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_index.php?page=course_wise_student_list">Course Wise Student List</a></li>
									<li><a class="nav-link" href="admin_index.php?page=student_active_account"></a></li>
									<li><a class="nav-link" href="admin_index.php?page=student_inactive_account">t</a></li>
								</ul>
							</li>
						     
						</ul>
					</nav>
					
				</div>				
				<div class="col-sm-12 col-md-12 col-lg-9 col-xxl-10"> 
				<?php
                  
                  if(isset($_GET['page'])){
                      $page=$_GET['page'].'.php';
                  } else {
                   $page='admin_dashboard_page.php';
                  }
                  
                  if(file_exists($page)){
                      require $page;
                  } else {
                      require '404.php';
                  }
                    
                    ?>
				</div>
			
	
			</div>
	</section>

</div>
</div>
<?php require_once('footer_copyright.php') ?>
	<script src="./js/jquery-3.5.1.js"></script>
    <script src="./js/jquery.dataTables.min.js"></script>
    <script src="./js/dataTables.bootstrap5.min.js"></script>
	<script src="./js/bootstrap.min.js"></script>
	<script src="./js/popper.min.js"></script>
	<script src="./js/form.js"></script>
	<script type="text/javascript" src="./js/dashboard.js"></script>

	<!-- copy csv excel pdf -->
	<script src="../js/dataTables.buttons.min.js"></script>
	<script src="../js/jszip.min.js"></script>
	<script src="../js/pdfmake.min.js"></script>
	<script src="../js/vfs_fonts.js"></script>
	<script src="../js/buttons.html5.min.js"></script>
	<script src="../js/buttons.print.min.js"></script>
	
		<!-- copy csv excel pdf -->

	<script type="text/javascript">

$(document).ready(function() {
    $('#data_table').DataTable({
		scrollY:'1000px',
	});
	$('#data_table_report').DataTable({
		dom: 'Bfrtip',
		
		buttons: [
			'copy', 'csv', 'excel', 'print',
            {
                extend: 'pdfHtml5',
				
                orientation: 'landscape',
                pageSize: 'A4'
            }
        ],

		scrollY:'600px',
	});
} );

	</script>
<script src="js/invoice.js"></script>
<script src="js/computerInvoice.js"></script>

</body>
</html>