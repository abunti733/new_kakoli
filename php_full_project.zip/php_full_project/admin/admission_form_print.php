<?php
require_once 'db_con.php';
session_start();
$admission_id  =  $_SESSION['admission_id'];    
$admission_data_select = mysqli_query($db_con , "SELECT * FROM `admission_form` WHERE `id`=$admission_id");
$admission_data_fatch = mysqli_fetch_assoc($admission_data_select);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/admission_form_design.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <div class="admission_form_main_body">
        <div class="container" id="container">
        <div class="page_top_section">
           <div class="page_top_row">
            <div class="page_top_col logo">
              <img width="100PX" src="images/site-icon.png" alt="">
            </div>
            <div class="page_top_col name_details">
                <div class="institute_name_english">
                    FUTURE COMPUTER TRANING INSTITUTE
                </div>
                <div class="institute_name_bangla">
                    ফিউচার কম্পিউটার ট্রেনিং ইনস্টিটিউট
                </div>
                <div class="institute_code_est">
                   <p class="institute_code"> Institute Code : 44047</p><p class="est">EST : 2017</p>
                </div>
                <p class="address">
                    Old Bus Stand , Al-Arafah Bank 3rd Floor , Madaripur
                </p>
                <div class="number_website_email">
                    <p class="number">CONTACT : +880 1928-248173</p><p class="website">WEBSITE : https://futurecomputer.net/</p>
                </div>

            </div>
            <div class="page_top_col btb_logo">
               <img width="100PX" src="images/bteb-logo.png" alt="">
            </div>
           </div>
        </div>
        <div class="admission_form">
            Admission Form
        </div>
        <div class="user_id_register_type">
            <p>User ID : <?=$admission_data_fatch['id'];?></p>
            <p class="problem">Admission Date :<?=$admission_data_fatch['admission_time'];?></p>
        </div>
         
        <div class="table_and_user_photo">
        <div class="user_photo">
          <img width="150px" height="155px" src="images/<?=$admission_data_fatch['photo'];?>" alt="">
        </div>
        <div class="table">
             <table >
                <tr>
                    <td>Roll</td>
                    <td><?=$admission_data_fatch['id'];?></td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><?=$admission_data_fatch['student_name'];?></td>
                </tr>
                <tr>
                    <td>Student Mobile </td>
                    <td><?=$admission_data_fatch['phone_number'];?></td>
                </tr>
                <tr>
                    <td>Guardian Mobile</td>
                    <td><?=$admission_data_fatch['guardian_number'];?></td>
                </tr>
                <tr>
                    <td>Course</td>
                    <td><?=$admission_data_fatch['course'];?></td>
                </tr>
                <tr>
                    <td>Session</td>
                    <td><?=$admission_data_fatch['session'];?></td>
                </tr>
                <tr>
                <td>Register Type</td>
                <td><?=$admission_data_fatch['registration_type'];?></td>
                </tr>
             </table>
        </div>
        </div>

        <div class="table_2_3">
            <div class="table_2">
                <table>
                <tr>
                    <td>Father Name</td>
                    <td><?=$admission_data_fatch['father_name'];?></td>
                </tr>
                <tr>
                    <td>Mother Name </td>
                    <td><?=$admission_data_fatch['mother_name'];?></td>
                </tr>        
                <tr>
                    <td>Division</td>
                    <td><?=$admission_data_fatch['division'];?></td>
                </tr>
                <tr>
                    <td>District</td>
                    <td><?=$admission_data_fatch['district'];?></td>
                </tr>
                <tr>
                    <td>Thana</td>
                    <td><?=$admission_data_fatch['thana'];?></td>
                </tr>
                <tr>
                    <td>Post Office</td>
                    <td><?=$admission_data_fatch['post_office'];?></td>
                </tr>
                <tr>
                    <td>Village</td>
                    <td><?=$admission_data_fatch['village'];?></td>
                </tr>

                </table>
            </div>
            <div class="table_3">
            <table>
                <tr>
                    <td>Religion</td>
                    <td><?=$admission_data_fatch['religion'];?></td>
                </tr>
                <tr>
                    <td>Job Title</td>
                    <td><?=$admission_data_fatch['job_title'];?></td>
                </tr>
                <tr>
                    <td>Date Of Birth</td>
                    <td><?=$admission_data_fatch['dob'];?></td>
                </tr>
                <tr>
                    <td>Nid/Birth Certificate</td>
                    <td><?=$admission_data_fatch['nid_birth_certificate'];?></td>
                </tr>
                <tr>
                    <td>Blood Group</td>
                    <td><?=$admission_data_fatch['blood_group'];?></td>
                </tr>
                <tr>
                    <td>Gander</td>
                    <td><?=$admission_data_fatch['gender'];?></td>
                </tr>

                <tr>
                    <td>Email</td>
                    <td><?=$admission_data_fatch['email'];?></td>
                </tr>

                </table>
            </div>
        </div>

        <div class="education">
            <div class="title">
                Education :
            </div>
            <table>
                <tr>
                    <td>Certificate</td>
                    <td>Board</td>
                    <td>Roll</td>
                    <td>Year</td>
                    <td>GPA</td>
                </tr>
                <tr>
                    <td>SSC</td>
                    <td><?=$admission_data_fatch['ssc_board'];?></td>
                    <td><?=$admission_data_fatch['ssc_roll'];?></td>
                    <td><?=$admission_data_fatch['ssc_year'];?></td>
                    <td><?=$admission_data_fatch['ssc_gpa'];?></td>
                </tr>
                <tr>
                    <td>JSC</td>
                    <td><?=$admission_data_fatch['jsc_board'];?></td>
                    <td><?=$admission_data_fatch['jsc_roll'];?></td>
                    <td><?=$admission_data_fatch['jsc_year'];?></td>
                    <td><?=$admission_data_fatch['jsc_gpa'];?></td>
                </tr>
                </table>
        </div>



            <div class="rules">
            <p><i class="fa-solid fa-hand-point-right"></i><span>ভর্তি ফি কোনো মতেই ফেরত যোগ্য নয় ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>ছাত্র/ছাত্রীদের ব্যাক্তিগত কারণ বসত কোর্স টি সম্পূর্ণ না করতে পারলে প্রতিষ্ঠান দায়ী থাকবে না  ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>ভর্তির সময় মিনিমাম ৭০% ফি দিতে হবে । বাকি টাকা ১ মাস ১০ দিনের মধ্যে জমা দিতে হবে । </span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>নির্ধারিত সময়ের মধ্যে টাকা না দিতে পারলে ৫০০ টাকা জরিমানা দিতে হবে ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>ভর্তি ফি ও আইডি কার্ড বাবদ ২০০ টাকা প্রদান করতে হবে ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>রেজিষ্ট্রেশন ফি বাবদ ৬৫০/- টাকা রেজিষ্ট্রেশনের সময় দিতে হবে ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>ক্লাসে প্রবেশ কারার সময় অবশ্যই উপস্থিত মেশিন এ ফিঙ্গারপ্রিন্ট দিয়ে প্রবেশ কারতে হবে  ।</span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>প্রতিষ্ঠানের সকল নিয়ম মেনে ক্লাস করতে হবে । </span></p>
            <p><i class="fa-solid fa-hand-point-right"></i><span>পরিক্ষা না দিরে কোনো শিক্ষার্থী লাইভটাইম সুবিধা পাবে না  । </span></p>
            </div>


        <div class="assure_that">
            <p>I assure <span>......................................................</span>that i will abide by all the rules and regulations of FCTI .  I will not to do any irregularity .  In case of any irregularity , the authority may take any legal action against me .</p>
        </div>

<div class="sign">
<div class="student_sign ">
    <p>Student Signature</p>
</div>

<div class="teacher_sign  ">
<p>Director Signature</p>
</div>

</div>

</div>

<div class="bottom_section">
    <div class="bottom_section_row">
        <div class="bottom_section_col">
        Copyright © 2012-2023 FCTI Inc all rights reserved.
        </div>
        <div class="bottom_section_col">
        <span>Powered by </span><img width="100px" src="images/fcti-footer-logo.png" alt="">
        </div>
    </div>
</div>

</div>
</body>
</html>