		<div class="footer-bottom">
			<div class="copyright"><p>Copyright &copy; 2012-<?= date("Y") ?> FCTI Inc all rights reserved | Powered by <a target="_blank" href="https://fctisoftware.com">FCTI</a></p></div>
		</div>

		<button id="scrollTopBtn"><i class="fa-solid fa-arrow-up"></i></button>