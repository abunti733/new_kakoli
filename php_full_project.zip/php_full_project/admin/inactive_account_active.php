<?php
	require_once 'db_con.php';
	session_start();
    $status=base64_decode($_GET['status']);
    $update_active = mysqli_query($db_con , "UPDATE `admission_form` SET `status`='Active' WHERE `id`='$status'");
    if($update_active){
        header('location:admin_index.php?page=student_inactive_account');
    }

?>