<?php
require_once 'db_con.php';
$student_id  =  $_SESSION['student_id']; 
$student_data_select= mysqli_query($db_con, "SELECT * FROM `admission_form` WHERE `id`='$student_id'");
$student_data= mysqli_fetch_assoc($student_data_select);
?>
<nav class="sidebar card">
	<div class="profile text-center">
		<img class="rounded-circle" style="border: 3px solid #dee2e6;" width="150" height="150" src="images/<?=$student_data['photo'];?>" alt=""><br>
		<label class="py-2 d-block" for=""><?=$student_data['student_name']?></label>
	</div>
	<ul class="nav flex-column" id="nav_accordion">
		<li class="nav-item has-submenu">
			<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-user nav-icon"></i><i class="fa-solid fa-caret-down"></i>Profile</a>
			<ul class="submenu collapse">
				<li><a class="nav-link" href="admin_index.php?page=student_admin_index">Personal Info</a></li>
			</ul>
		</li>		
		<li class="nav-item has-submenu">
			<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-graduation-cap nav-icon"></i><i class="fa-solid fa-caret-down"></i>Education</a>
			<ul class="submenu collapse">
				<li><a class="nav-link" href="admin_index.php?page=student_education_info">Education Info</a></li>
			</ul>
		</li>	
		<li class="nav-item has-submenu">
			<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-bars nav-icon"></i><i class="fa-solid fa-caret-down"></i>Course Info</a>
			<ul class="submenu collapse">
				<li><a class="nav-link" href="admin_index.php?page=student_course_info">Course Info</a></li>
			</ul>
		</li>	
		<li class="nav-item has-submenu">
			<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-phone nav-icon"></i><i class="fa-solid fa-caret-down"></i>Contact Info</a>
			<ul class="submenu collapse">
				<li><a class="nav-link" href="admin_index.php?page=student_contact_info">Contact Info</a></li>
			</ul>
		</li>		
		<li class="nav-item has-submenu">
			<a class="nav-link list-group-item" href="#"><i class="fa-solid fa-money-bill nav-icon"></i><i class="fa-solid fa-caret-down"></i>Payment</a>
			<ul class="submenu collapse">
				<li><a class="nav-link" href="admin_index.php?page=student_payment_list">Payment list</a></li>
				<li><a class="nav-link" href="admin_index.php?page=student_payment_add">Add Payment</a></li>
			</ul>
		</li>					
	</ul>
</nav>