<?php 
require_once 'db_con.php';

$student_id  =  $_SESSION['student_id'];    
$student_id_query= mysqli_query($db_con, "SELECT * FROM `admission_form` WHERE `id`='$student_id'");
$student_admin_data= mysqli_fetch_assoc($student_id_query);
if(isset($_POST['update_submit'])){
	$phone_number = $_POST['phone_number'];
	$guardian_number = $_POST['guardian_number'];
    $email = $_POST['email'];
    $division = $_POST['divisions'];
    $distr = $_POST['distr'];
    $thana = $_POST['thana'];
    $post_office = $_POST['post_office'];
    $village = $_POST['village'];


    $student_update=mysqli_query($db_con,"UPDATE `admission_form` SET `phone_number`='$phone_number',`guardian_number`='$guardian_number',`email`='$email',`division`='$division',`district`='$distr',`thana`='$thana',`post_office`='$post_office',`village`='$village' WHERE `id`='$student_id'");

    if($student_update){
        echo "<script>
          alert('Your Data successfully updated!');
      window.location.href='admin_index.php?page=student_admin_index'; 
        </script>";
    }else{
        echo "<script>
        alert('Your Data updated failed!');
     window.location.href='admin_index.php?page=student_admin_index'; 
      </script>";
    }
}


?>
<div class="main_div p-3">
<div class="container-fluid" style="padding-left:0;position:relative;">
<section class="section-content">
	<div class="row d-flex">
				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-3 col-xxl-2">
				<?php require_once ('student_admin_sidebar.php');?>	
				</div>
				<div class="col-sm-12 col-md-12 col-lg-8 col-xl-9 col-xxl-10"> 
					<div class="student_profile">
						<h1 style="color:#65BDB6;"><i class="fa-solid fa-phone px-2" style="font-size:35px"></i>Student Contact Info<small> Statistics Overview</small></h1>
						<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
						<ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-gauge px-2" style="font-size:18px;color:#65BDB6;"></i>Dashboard</a></li>
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="" class="text-decoration-none"><i class="fa-solid fa-phone px-2" style="font-size:18px;color:#65BDB6;"></i>Contact Information</a></li>
						</ol>
						</nav>
			        </div>
<div class="row">
<div class="personal_info col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
<table class="table table-bordered">

<tr>
<th>Student Number</th>
<td><?=$student_admin_data['phone_number']?></td>
</tr>
<tr>
<th>Guardian Number</th>
<td><?=$student_admin_data['guardian_number']?></td>
</tr>
<tr>
<th>Email</th>
<td><?=$student_admin_data['email']?></td>
</tr>
<tr>
	<th>Division</th>
	<td><?=$student_admin_data['division'];?></td>
</tr>
<tr>
	<th>District</th>
	<td><?=$student_admin_data['district'];?></td>
</tr>
<tr>
	<th>Thana</th>
	<td><?=$student_admin_data['thana'];?></td>
</tr>
<tr>
	<th>Post Office</th>
	<td><?=$student_admin_data['post_office'];?></td>
</tr>
<tr>
	<th>Village</th>
	<td><?=$student_admin_data['village'];?></td>
</tr>
</table>
<button data-bs-toggle="modal" data-bs-target="#teacherunique<?=$student_admin_data['id']?>" data-bs-whatever="@mdo" class="btn btn-primary" ><i class="fa-solid fa-pencil px-1"></i>Edit Info</button>
<!-- modal section -->
<div id="teacherunique<?=$student_admin_data['id']?>" class="modal fade" role="dialog">
							  <div class="modal-dialog" style="max-width:700px;">
								<div class="modal-content bg-light">
								  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Update Personal Information</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									  </div>
									  <div class="modal-body">
									  
										<form method="POST" action=""  enctype="multipart/form-data">
										<div class="row">
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                            <div class="mb-3">
											<label for="phone_number" class="form-label">Phone Number</label>
											<input type="text" class="form-control"  id="phone_number" name="phone_number" value="<?php echo $student_admin_data['phone_number']?>">
										  </div>
                                          <div class="mb-3">
											<label for="guardian_number" class="form-label">Guardian Number</label>
											<input type="text" class="form-control"  id="guardian_number" name="guardian_number" value="<?php echo $student_admin_data['guardian_number']?>">
										  </div>
                                          <div class="mb-3">
											<label for="email" class="form-label">Email</label>
											<input type="email" class="form-control"  id="email" name="email" value="<?php echo $student_admin_data['email']?>">
										  </div>
                                          <div class="mb-3">
											<label for="divisions" class="form-label">Division</label>
											<input type="text" class="form-control"  id="divisions" name="divisions" value="<?php echo $student_admin_data['division']?>">
										  </div>


											</div>
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                            <div class="mb-3">
											<label for="distr" class="form-label">District</label>
											<input type="text" class="form-control"  id="distr" name="distr" value="<?php echo $student_admin_data['district']?>">
										  </div>
                                          <div class="mb-3">
											<label for="thana" class="form-label">Thana</label>
											<input type="text" class="form-control"  id="thana" name="thana" value="<?php echo $student_admin_data['thana']?>">
										  </div>
                                          <div class="mb-3">
											<label for="post_office" class="form-label">Post Office</label>
											<input type="text" class="form-control"  id="post_office" name="post_office" value="<?php echo $student_admin_data['post_office']?>">
										  </div>
                                          <div class="mb-3">
											<label for="village" class="form-label">Village</label>
											<input type="text" class="form-control"  id="village" name="village" value="<?php echo $student_admin_data['village']?>">
										  </div>



											</div>  
										</div>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
										<button type="submit" class="btn btn-primary" name="update_submit">Update</button>
									  </div>
									  </form>
									</div>
								  </div>
</div>									
<!-- modal section -->
</div>
</div>
</div>
</div>
</section>
</div>
</div>