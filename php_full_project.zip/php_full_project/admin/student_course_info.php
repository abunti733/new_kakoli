<?php 
require_once 'db_con.php';

$student_id  =  $_SESSION['student_id'];    
$student_id_query= mysqli_query($db_con, "SELECT * FROM `admission_form` WHERE `id`='$student_id'");
$student_admin_data= mysqli_fetch_assoc($student_id_query);
if(isset($_POST['update_course_info'])){
$course = $_POST['course'];
$course_fee = $_POST['course_fee'];
$session = $_POST['session'];
$registration_type = $_POST['registration_type'];

    $student_update=mysqli_query($db_con,"UPDATE `admission_form` SET `session`='$session',`course`='$course',`registration_type`='$registration_type',`total_fee`='$course_fee' WHERE `id`='$student_id'");

    if($student_update){
        echo "<script>
          alert('Your Data successfully updated!');
      window.location.href='admin_index.php?page=student_course_info'; 
        </script>";
    }else{
        echo "<script>
        alert('Your Data updated failed!');
     window.location.href='admin_index.php?page=student_course_info'; 
      </script>";
    }
}


?>
<div class="main_div p-3">
<div class="container-fluid" style="padding-left:0;position:relative;">
<section class="section-content">
	<div class="row d-flex">
				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-3 col-xxl-2">
				<?php require_once ('student_admin_sidebar.php');?>	
				</div>
				<div class="col-sm-12 col-md-12 col-lg-8 col-xl-9 col-xxl-10"> 
					<div class="student_profile">
						<h1 style="color:#65BDB6;"><i class="fa-solid fa-bars px-2" style="font-size:35px"></i>Student Course Info<small> Statistics Overview</small></h1>
						<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
						<ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-gauge px-2" style="font-size:18px;color:#65BDB6;"></i>Dashboard</a></li>
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="" class="text-decoration-none"><i class="fa-solid fa-bars px-2" style="font-size:18px;color:#65BDB6;"></i>Course Information</a></li>
						</ol>
						</nav>
			        </div>
<div class="row">
<div class="personal_info col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
<table class="table table-bordered">
<tr>
<th>Course </th>
<td><?=$student_admin_data['course']?></td>
</tr>
<tr>
<th>Course Fee</th>
<td><?=$student_admin_data['total_fee']?></td>
</tr>
<tr>
<th>Session</th>
<td><?=$student_admin_data['session']?></td>
</tr>
<tr>
<th>Admission Date</th>
<td><?=$student_admin_data['admission_time']?></td>
</tr>
<tr>
<th>Registration Type</th>
<td><?=$student_admin_data['registration_type']?></td>
</tr>
<tr>
<th>Batch Name</th>
<td></td>
</tr>
</table>
<button data-bs-toggle="modal" data-bs-target="#teacherunique<?=$student_admin_data['id']?>" data-bs-whatever="@mdo" class="btn btn-primary" ><i class="fa-solid fa-pencil px-1"></i>Edit Info</button>
<!-- modal section -->
<div id="teacherunique<?=$student_admin_data['id']?>" class="modal fade" role="dialog">
							  <div class="modal-dialog" style="max-width:700px;">
								<div class="modal-content bg-light">
								  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Update Personal Information</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									  </div>
									  <div class="modal-body">
									  
										<form method="POST" action=""  enctype="multipart/form-data">
										<div class="row">
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
										  <div class="mb-3">
											<label for="course" class="form-label">Course</label>
											<input type="text" class="form-control"  id="course" name="course" value="<?php echo $student_admin_data['course']?>">
										  </div>
										  <div class="mb-3">
											<label for="course_fee" class="form-label">Course Fee</label>
											<input type="text" class="form-control"  id="course_fee" name="course_fee" value="<?php echo $student_admin_data['total_fee']?>">
										  </div>
										  <div class="mb-3">
											<label for="session" class="form-label">Session</label>
											<input type="text" class="form-control"  id="session" name="session" value="<?php echo $student_admin_data['session']?>">
										  </div>
                                          <div class="mb-3">
											<label for="registration_type" class="form-label">Registration Type</label>
											<input type="text" class="form-control"  id="registration_type" name="registration_type" value="<?php echo $student_admin_data['registration_type']?>">
										  </div>

											</div>
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                           
											</div>  
										</div>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
										<button type="submit" class="btn btn-primary" name="update_course_info">Update</button>
									  </div>
									  </form>
									</div>
								  </div>
</div>									
<!-- modal section -->
</div>
</div>
</div>
</div>
</section>
</div>
</div>