<?php
require("db_con.php");
session_start();
$student_id=base64_decode($_GET['student_id']);
$delete_data = mysqli_query($db_con , "DELETE FROM `admission_form` WHERE `id`='$student_id'");
if($delete_data){
    header('location:admin_index.php?page=admin_dashboard_page');
}
?>