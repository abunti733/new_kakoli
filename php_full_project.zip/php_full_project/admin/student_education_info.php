<?php 
require_once 'db_con.php';
$student_id  =  $_SESSION['student_id'];    
$student_id_query= mysqli_query($db_con, "SELECT * FROM `admission_form` WHERE `id`='$student_id'");
$student_admin_data= mysqli_fetch_assoc($student_id_query);

if(isset($_POST['update_edu_info'])){
	$ssc_board = $_POST['ssc_board'];
    $ssc_roll = $_POST['ssc_roll'];
    $ssc_year = $_POST['ssc_year'];
    $ssc_gpa = $_POST['ssc_gpa'];
    $jsc_board = $_POST['jsc_board'];
    $jsc_roll = $_POST['jsc_roll'];
    $jsc_year = $_POST['jsc_year'];
    $jsc_gpa = $_POST['jsc_gpa'];



   $edu_updata = mysqli_query($db_con , "UPDATE `admission_form` SET `ssc_board`='$ssc_board',`ssc_roll`='$ssc_roll',`ssc_year`='$ssc_year',`ssc_gpa`='$ssc_gpa',`jsc_board`='$jsc_board',`jsc_roll`='$jsc_roll',`jsc_year`='$jsc_year',`jsc_gpa`='$jsc_gpa' WHERE `id`='$student_id'");

    if($edu_updata){
        echo "<script>
          alert('Your Data successfully updated!');
      window.location.href='admin_index.php?page=student_education_info'; 
        </script>";
    }else{
        echo "<script>
        alert('Your Data updated failed!');
     window.location.href='admin_index.php?page=student_education_info'; 
      </script>";
    }
}
?>


<div class="main_div p-3">
<div class="container-fluid" style="padding-left:0;position:relative;">
<section class="section-content">
	<div class="row d-flex">
				<div class="col-sm-12 col-md-12 col-lg-4 col-xl-3 col-xxl-2">
				<?php require_once ('student_admin_sidebar.php');?>	
				</div>
				<div class="col-sm-12 col-md-12 col-lg-8 col-xl-9 col-xxl-10"> 
					<div class="student_profile">
						<h1 style="color:#65BDB6;"><i class="fa-solid fa-graduation-cap px-2" style="font-size:35px"></i>Student Education Info<small> Statistics Overview</small></h1>
						<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
						<ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-gauge px-2" style="font-size:18px;color:#65BDB6;"></i>Dashboard</a></li>
							<li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="" class="text-decoration-none"><i class="fa-solid fa-graduation-cap px-2" style="font-size:18px;color:#65BDB6;"></i>Education Information</a></li>
						</ol>
						</nav>
			        </div>
<div class="row">
<div class="personal_info col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
<table class="table table-bordered" style="width: 100%;">
<tr>
<th>Certificate </th>
<td>Board</td>
<td>Roll</td>
<td>Year</td>
<td>GPA</td>
</tr>
<tr>
<th>SSC</th>
<td><?=$student_admin_data['ssc_board']?></td>
<td><?=$student_admin_data['ssc_roll']?></td>
<td><?=$student_admin_data['ssc_year']?></td>
<td><?=$student_admin_data['ssc_gpa']?></td>
</tr>
<th>JSC</th>
<td><?=$student_admin_data['jsc_board']?></td>
<td><?=$student_admin_data['jsc_roll']?></td>
<td><?=$student_admin_data['jsc_year']?></td>
<td><?=$student_admin_data['jsc_gpa']?></td>
</tr>
</table>
<button data-bs-toggle="modal" data-bs-target="#teacherunique<?=$student_admin_data['id']?>" data-bs-whatever="@mdo" class="btn btn-primary" ><i class="fa-solid fa-pencil px-1"></i>Edit Info</button>
<!-- modal section -->
<div id="teacherunique<?=$student_admin_data['id']?>" class="modal fade" role="dialog">
							  <div class="modal-dialog" style="max-width:700px;">
								<div class="modal-content bg-light">
								  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Update Personal Information</h5>
										<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									  </div>
									  <div class="modal-body">
									  
										<form method="POST" action=""  enctype="multipart/form-data">
										<div class="row">
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
										  <div class="mb-3">
											<label for="ssc_board" class="form-label">SSC Board</label>
											<input type="text" class="form-control"  id="ssc_board" name="ssc_board" value="<?php echo $student_admin_data['ssc_board']?>">
										  </div>
										  <div class="mb-3">
											<label for="ssc_roll" class="form-label">SSC Roll</label>
											<input type="text" class="form-control"  id="ssc_roll" name="ssc_roll" value="<?php echo $student_admin_data['ssc_roll']?>">
										  </div>
										  <div class="mb-3">
											<label for="ssc_year" class="form-label">SSC Year</label>
											<input type="text" class="form-control"  id="ssc_year" name="ssc_year" value="<?php echo $student_admin_data['ssc_year']?>">
										  </div>
                                          <div class="mb-3">
											<label for="ssc_gpa" class="form-label">SSC GPA</label>
											<input type="text" class="form-control"  id="ssc_gpa" name="ssc_gpa" value="<?php echo $student_admin_data['ssc_gpa']?>">
										  </div>

											</div>
											<div class="col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                                            <div class="mb-3">
											<label for="jsc_board" class="form-label">JSC Board</label>
											<input type="text" class="form-control"  id="jsc_board" name="jsc_board" value="<?php echo $student_admin_data['jsc_board']?>">
										  </div>
										  <div class="mb-3">
											<label for="jsc_roll" class="form-label">JSC Roll</label>
											<input type="text" class="form-control"  id="jsc_roll" name="jsc_roll" value="<?php echo $student_admin_data['jsc_roll']?>">
										  </div>
										  <div class="mb-3">
											<label for="jsc_year" class="form-label">JSC Year</label>
											<input type="text" class="form-control"  id="jsc_year" name="jsc_year" value="<?php echo $student_admin_data['jsc_year']?>">
										  </div>
                                          <div class="mb-3">
											<label for="jsc_gpa" class="form-label">JSC GPA</label>
											<input type="text" class="form-control"  id="jsc_gpa" name="jsc_gpa" value="<?php echo $student_admin_data['jsc_gpa']?>">
										  </div>
											</div>  
										</div>
									  </div>
									  <div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
										<button type="submit" class="btn btn-primary" name="update_edu_info">Update</button>
									  </div>
									  </form>
									</div>
								  </div>
</div>									
<!-- modal section -->
</div>
</div>
</div>
</div>
</section>
</div>
</div>