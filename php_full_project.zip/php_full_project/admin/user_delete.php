<?php
require("db_con.php");
session_start();
$user_id=base64_decode($_GET['user_id']);
$delete_data = mysqli_query($db_con , "DELETE FROM `user_register_data` WHERE `id`='$user_id'");
if($delete_data){
    header('location:admin_index.php?page=user_list');
}
?>