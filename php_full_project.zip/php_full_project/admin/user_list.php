<h1 style="color:#65BDB6;"><i class="fa-solid fa-user-tie px-2" style="font-size:35px"></i>User List<small> Statistics Overview</small></h1>
<nav style="--bs-breadcrumb-divider: '';" aria-label="breadcrumb">
  <ol style="background-color:#f5f5f5;" class="breadcrumb  px-2 pt-2 py-2">
    <li class="breadcrumb-item"><a style="font-size:18px;color:#65BDB6;" href="admin_index.php?page=admin_dashboard " class="text-decoration-none"><i class="fa-solid fa-user-tie px-2" style="font-size:18px;color:#65BDB6;"></i>User List</a></li>
  </ol>
</nav>

<div class="table p-2">
		<table id="data_table" class="table table-striped table-hover">
		<thead>
            <tr>
                <th>User ID</th>
                <th>Username</th>
                <th>Name</th>
                <th>Father's Name</th>
                <th>Mobile</th>     
                <th>Register Time</th>        
                <th>Photo</th>
                <th>Action</th>
            </tr>
		</thead>
        <tbody>
           <?php
		   
				$admission_data_select_query=mysqli_query($db_con,"SELECT * FROM `user_register_data` WHERE `id`");
				while($all_student_data=mysqli_fetch_assoc($admission_data_select_query)){
           
					?>				
						<tr> 												
							
							<td><?=$all_student_data["id"];?></td>
              <td><?=$all_student_data["username"];?></td>
							<td><?=$all_student_data["name"];?></td>
							<td><?=$all_student_data["father name"];?></td>
							<td><?=$all_student_data["phone"];?></td>
							<td><?=$all_student_data["register time"];?></td>
							<td><img src="images/<?=$all_student_data['photo'];?>" class="img-thumbnail s_photo"/></td>
                            <td>
								<div class="btn-group">
										<button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
											Action
										</button>
										<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="student_profile_function.php?user_id=<?php echo base64_encode($all_student_data['id']);?>">View</a></li>
							
															<li><a class="dropdown-item" onclick="return confirm('Are you sure to delete this data?')" href="user_delete.php?user_id=<?=base64_encode($all_student_data["id"])?>">Delete</a>
															</li>
									</ul>
									</div>
									</td>


                                   
												
					
				

																			
						</tr>
					
					<?php
				
				}	
		?>
        </tbody>
    </table>
</div>